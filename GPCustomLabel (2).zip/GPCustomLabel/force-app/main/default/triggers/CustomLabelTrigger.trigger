trigger CustomLabelTrigger on Custom_Label__c (before delete) {
    CustomLabelTriggerHandler.preventDeletion(Trigger.old);
}
