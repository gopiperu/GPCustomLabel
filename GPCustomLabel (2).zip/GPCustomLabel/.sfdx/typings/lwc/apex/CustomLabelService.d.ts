declare module "@salesforce/apex/CustomLabelService.getLabels" {
  export default function getLabels(param: {labelKeys: any}): Promise<any>;
}
declare module "@salesforce/apex/CustomLabelService.getLabelsByType" {
  export default function getLabelsByType(param: {type: any}): Promise<any>;
}
declare module "@salesforce/apex/CustomLabelService.getLabelsByTypeAndSubType" {
  export default function getLabelsByTypeAndSubType(param: {type: any, subType: any}): Promise<any>;
}
